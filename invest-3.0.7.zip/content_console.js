if(document.location.pathname == '/') 
  document.location.href = '/dashboard'