if(document.location.pathname == '/')
  chrome.runtime.sendMessage('login');